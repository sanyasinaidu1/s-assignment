const printData = require('../database/data')

function holidayCalander(req, res) {
    try {
        res.send('' + printData.holidayCalander)
    } catch(e) {
        res.send(400).send(e)
    }
}

module.exports.holidayCalander = holidayCalander