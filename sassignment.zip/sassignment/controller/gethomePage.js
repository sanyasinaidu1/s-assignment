function homePage (req,res){
    res.send(`HOME <br> <a href=/absentDays>/absentDays<a> 
    <br> <a href=/absentDetails>/absentDetails<a> 
    <br> <a href=/leavebalance>/leavebalance<a> 
    <br> <a href=/holidayCalander>/holidayCalander<a>`)
}

module.exports.homePage = homePage