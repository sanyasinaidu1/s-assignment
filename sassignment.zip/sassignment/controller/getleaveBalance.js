const printData = require('../database/data')

function leaveBalance(req, res) {
    try {
        res.send(printData.leaveBalance)
    } catch(e) {
        res.send(400).send(e)
    }
}

module.exports.leaveBalance = leaveBalance