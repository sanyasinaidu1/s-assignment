const printData = require('../database/data')

function absentDays(req, res) {
    try {
        res.send('' + printData.absentDays)
    } catch(e) {
        res.send(400).send(e)
    }
}

module.exports.absentDays = absentDays