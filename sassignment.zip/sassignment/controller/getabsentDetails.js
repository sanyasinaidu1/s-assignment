const printData = require('../database/data')

function absentDetails(req, res) {
    try {
        res.send(printData.absentDetails)
    } catch(e) {
        res.send(400).send(e)
    }
}

module.exports.absentDetails = absentDetails