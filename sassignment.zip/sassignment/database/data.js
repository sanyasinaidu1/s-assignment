const printData = {
    absentDays: 9,

    absentDetails: [
        "01-06-21",
        "02-06-21",
        "03-06-21",
        "04-06-21"
    ],

    leaveBalance: [
        {
            type: "Contingency Leave",
            remainLeaves: 6,
            valid_till: "31-12-21"
        },
        {
            type: "Optional holiday",
            remainLeaves: 3,
            valid_till: "31-12-21"
        },
        {
            type: "SpecialPrevilege leave",
            remainLeaves: 10,
            valid_till: "31-12-21"
        }
    ],

    holidayCalander: [
        {
            date: "15th August",
            day: "Sunday",
            occation: "Independence day"
        },
        {
            date: "10th September",
            day: "Friday",
            occation: "Ganesh chaturthi"
        },
        {
            date: "2nd October",
            day: "Saturday",
            occation: "Gandhi jayanthi"
        }
    ]
}

module.exports = printData