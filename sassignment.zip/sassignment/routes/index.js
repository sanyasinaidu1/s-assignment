const express = require('express');
const router = express.Router();

const getabsentDays = require('../controller/getabsentDays')
const getabsentDetails = require('../controller/getabsentDetails');
const gethomePage = require('../controller/gethomePage');
const getleaveBalance = require('../controller/getleaveBalance')
const getholidayCalander = require('../controller/getholidayCalander')

//absent days
router.get('/absentDays', (req,res) => {
    getabsentDays.absentDays(req, res)
})

//absent details
router.get('/absentDetails', (req,res) => {
    getabsentDetails.absentDetails(req, res)
})

//leave balance
router.get('/leaveBalance', (req,res) => {
    getleaveBalance.leaveBalance(req, res)
})

//holiday calender
router.get('/holidayCalander', (req,res) => {
    getholidayCalander.holidayCalander(req, res)
})

router.get('/', (req,res) => {
    gethomePage.homePage(req, res)
})

router.get('*', (req,res) => {
    res.redirect('/');
})

module.exports = router