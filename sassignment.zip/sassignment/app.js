const express = require('express');
const indexRouter = require('./routes/index')

//added express variable
const app = express();


app.use('/', indexRouter)


//starting server on the required port
app.listen(3000, () => {
    console.log('Server is running on port 3000')
})