const express=require('express')
const app=express()


app.get('',(req,res)=>{
  res.send('home page')
})
app.get('/absentDays',(req,res)=>{
    res.send({
        absentDays: '9'
    })
  })
  
app.get('/absentDetails',(req,res)=>{
    res.send({
        absentDetails:
        ['1/6/21','2/6/21','3/6/21','4/6/21']
    })
  })

app.get('/leaveBalance',(req,res)=>{
    res.send({
        leaveBalance:
        [{contingencyLeave: '6-31/12/21'},{optionalHoliday: '3-31/12/21'},{specialPrivilegeLeave: '10-31/12/21'}]
     })
  })
 
  app.get('/holidayCalender',(req,res)=>{
    res.send({
        holidayCalander:
        [{IndependenceDay:'15th August/Sunday'},{GaneshChaturthi:'10th September/Friday'},{GandhiJayanti:'2nd October/Saturday'}]
     })
  })
    
    

app.listen(3000,()=>{
    console.log('Server is running on port 3000')
})